import { useEffect } from 'react';

const Register = () => {
  useEffect(() => {
    window.location.href = 'https://rajalakshmi.org/datalore/';
  }, []);

  return null;
};

export default Register;

  
